# from sms_providers.provider_factory import get_sms_provider


# class SMSService:

#     def __init__(self):
#         self.provider = get_sms_provider()


#     async def send_sms(
#         self,
#         to_number: str,
#         message: str
#     ):
#         await self.provider.send_sms(
#             to_number=to_number,
#             message=message
#         )
